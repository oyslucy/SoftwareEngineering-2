#include "Exit.h"

bool Exit::exit() {
    return true;
}