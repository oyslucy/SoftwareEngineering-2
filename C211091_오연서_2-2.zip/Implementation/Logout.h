#ifndef LOGOUT_H
#define LOGOUT_H

#include "UserCollection.h"

class Logout {
public:
    string logout(UserCollection& userCollection);
};

#endif