#ifndef EXIT_H
#define EXIT_H

/**
 * @brief Exit 클래스
 * 이 클래스는 프로그램 종료 기능을 제공
 */
class Exit {
    public:
        bool exit(); /// 프로그램 종료 함수
};

#endif