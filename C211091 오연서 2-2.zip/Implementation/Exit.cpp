#include "Exit.h"

/**
 * @brief 프로그램 종료 요청 처리
 * 
 * @return 항상 true 반환 종료 플래그로 사용
 */
bool Exit::exit() {
    return true;
}